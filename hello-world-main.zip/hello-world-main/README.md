# hello-world
This repository is for practicing the GitHub Flow.

My name is Bella and I am a junior majoring in computer science. Outside of school, in my free time, I enjoy listening to music, hanging out with friends/family and also being a soccer coach. I have played soccer for over 10yrs and I currently play for Judson University.
