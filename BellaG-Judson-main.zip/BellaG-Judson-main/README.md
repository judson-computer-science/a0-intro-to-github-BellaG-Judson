# About me


- 🤓 I'm a junior in college majoring in Computer Science.
- 🌱 I’m currently learning to manage going to school, playing sports, and working all at the same time.
- 👯 I’m looking to collaborate on projects this year to further my understanding and proficiency in different areas.
- 🤔 I’m looking for help staying ahead on work to be less stressed.
- 💬 Ask me about soccer! I love it! I currently play for the women's team here at Judson and I also coach young players at a soccer club back in my home town.
- 📫 How to reach me: Text/call, social media, or just come up and talk to me.
- 😄 Pronouns: She/Her.
- ⚡ Fun fact: My family and I travel to Orlando Florida to go to Disney World every year for our family vacation.
